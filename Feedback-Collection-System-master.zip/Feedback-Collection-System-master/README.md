# Feedback-Collection-System
This project is a PM &amp; Startups orientated Feedback-Collection System (Fullstack)
